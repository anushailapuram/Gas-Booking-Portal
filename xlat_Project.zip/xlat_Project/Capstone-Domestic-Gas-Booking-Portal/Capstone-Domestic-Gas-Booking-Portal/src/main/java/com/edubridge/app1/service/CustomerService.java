package com.edubridge.app1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edubridge.app1.model.Customer;
import com.edubridge.app1.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository repo;
	
	public Customer saveCustomer(Customer customer) {
		return repo.save(customer);
	}
	
	public List<Customer> getCustomers(){
		return repo.findAll();
	}
	
	public Customer getCustomer(Integer customerId){
		return repo.findById(customerId).get();
	}
	
	public void updateCustomer(Customer customer){
		repo.save(customer);
	}
	
	public void deleteCustomer(Integer customerId){
		repo.deleteById(customerId);
	}
}