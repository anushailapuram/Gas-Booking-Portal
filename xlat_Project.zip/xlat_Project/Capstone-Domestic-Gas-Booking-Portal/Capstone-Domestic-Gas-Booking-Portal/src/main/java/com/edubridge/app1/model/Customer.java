package com.edubridge.app1.model;

import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name="PROJECT_CUSTOMER")
public class Customer {

		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private Integer customerId; 
		private String customerName;
		private String customerMail;
		private Long customerMobile;
		
		@OneToOne(cascade=CascadeType.ALL)
		@JoinColumn(name="address_Id", referencedColumnName="addressId")
		private Address customerAddress;

		
		
		
}


