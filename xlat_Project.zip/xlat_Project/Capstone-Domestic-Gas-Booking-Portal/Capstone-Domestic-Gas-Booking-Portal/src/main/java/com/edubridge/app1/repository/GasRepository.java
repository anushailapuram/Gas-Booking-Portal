package com.edubridge.app1.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.edubridge.app1.model.Gas;

@Repository
public interface GasRepository extends JpaRepository<Gas,Integer> {

}
