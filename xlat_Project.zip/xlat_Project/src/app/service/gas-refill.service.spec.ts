import { TestBed } from '@angular/core/testing';

import { GasRefillService } from './gas-refill.service';

describe('GasRefillService', () => {
  let service: GasRefillService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(GasRefillService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
