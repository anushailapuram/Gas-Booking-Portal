import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomerService } from '../../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-create',
  templateUrl: './customer-create.component.html',
  styleUrl: './customer-create.component.css'
})
export class CustomerCreateComponent {

  customerFormGroup: FormGroup

  constructor(
    private formBuilder:FormBuilder, 
    private customerService:CustomerService,
    private router:Router
  ){}

  ngOnInit(){
     this.customerFormGroup=this.formBuilder.group({
      customerName:['',[Validators.required]],
      customerMail:['',[Validators.required]],
      customerMobile:['',[Validators.required]],
      customerCity:['',[Validators.required]],
      customerState:['',[Validators.required]],
      customerCountry:['',[Validators.required]],
      customerPincode:['',[Validators.required]]
     });
  }

  addCustomer(){
    if(this.customerFormGroup.valid){
      this.customerService
      .createCustomer(this.customerFormGroup.value)
      .subscribe((data)=>{
          alert('new Customer Registration Succesfull!');
          this.router.navigateByUrl('/customer-list');
      });
    }
    if(this.customerFormGroup.invalid){
      //alert('form is invalid');
      this.customerFormGroup.markAllAsTouched();
    }
  }
}
