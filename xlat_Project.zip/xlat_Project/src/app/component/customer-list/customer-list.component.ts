import { Component } from '@angular/core';
import { Customer } from '../../model/customer';
import { GasRefill } from '../../model/gasrefill';
import { CustomerService } from '../../service/customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrl: './customer-list.component.css'
})
export class CustomerListComponent {

  customers: Customer[]=[];

  constructor(
    private CustomerService:CustomerService,
    private router:Router
  ){}

  ngOnInit()
  {
    this.getAllCustomers();
  }

  getAllCustomers(){
    this.CustomerService.getCustomers().subscribe((data)=>{
      this.customers=data;

    });
  }

  removeCustomer(customerId: number) {
    if(confirm('Are you sure delete this customer?')){
      this.CustomerService.deleteCustomer(customerId).subscribe((data) =>{
        alert('Customer successfully Deleted!!');
        this.getAllCustomers();
      });
    }
  }

  showEdit(customerId: number) {
    this.router.navigate(['edit', customerId]);

  }

  bookGas(customerId: number){

    this.router.navigate(['book-gas',customerId])
  }

}
