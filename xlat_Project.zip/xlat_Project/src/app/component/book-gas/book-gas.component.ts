import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../../model/customer';
import { CustomerService } from '../../service/customer.service';


@Component({
  selector: 'app-book-gas',
  templateUrl: './book-gas.component.html',
  styleUrl: './book-gas.component.css'
})
export class BookGasComponent {
  customerId:any;
  customerFormGroup:FormGroup

  customer: Customer=new Customer();
  constructor(
    private formBuilder:FormBuilder, 
    private customerService:CustomerService,
    private router:Router,
    private activatedRouts:ActivatedRoute
  ){}

  ngOnInit(){
   
    this.customerFormGroup =this.formBuilder.group({
      
      gasRefillDMY:['',[Validators.required]],
     });

    
     this.customerId = this.activatedRouts.snapshot.params['customerId'];

     this.customerService.getCustomer(this.customerId).subscribe((data) =>{
       this.customer = data;

  })
  }

  bookGas(){
    if(confirm("Are sure to Book Gas")){
      this.customerService.updateCustomer(this.customer, this.customerId).subscribe((data)=>{
        alert('Gas Booking Succesfull');
       
      });
    }
  }
}
