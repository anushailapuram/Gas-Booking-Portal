import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BookGasComponent } from './book-gas.component';

describe('BookGasComponent', () => {
  let component: BookGasComponent;
  let fixture: ComponentFixture<BookGasComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BookGasComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BookGasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
