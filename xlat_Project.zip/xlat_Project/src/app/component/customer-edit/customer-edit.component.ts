import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../../model/customer';
import { CustomerService } from '../../service/customer.service';


@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrl: './customer-edit.component.css'
})
export class CustomerEditComponent {
  customerId:any
  customerFormGroup:FormGroup

  customer: Customer=new Customer();
  constructor(
    private formBuilder:FormBuilder, 
    private customerService:CustomerService,
    private router:Router,
    private activatedRouts:ActivatedRoute
  ){}

  ngOnInit(){
   
    this.customerFormGroup =this.formBuilder.group({
      customerName:['',[Validators.required, Validators.pattern('[A-Za-z]+')]],
      customerEmail:['',[Validators.required, Validators.email]],
      customerMobile:['',[Validators.required, Validators.pattern('[6-9][0-9]{9}')]],
      customerRefills:['',[Validators.required]],
     });

    
     this.customerId = this.activatedRouts.snapshot.params['customerId'];

     this.customerService.getCustomer(this.customerId).subscribe((data) =>{
       this.customer = data;

  })
  }

  editCustomer(){
    if(confirm("Are sure to edit details")){
      
      this.customerService.updateCustomer(this.customer,this.customerId).subscribe((data)=>{
        alert('update Successfull');
        this.router.navigateByUrl('/customer-list');
      });
    }
  }
}
