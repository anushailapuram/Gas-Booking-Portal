export class GasRefill {
    gasRefillId:number;
    gasRefillDMY:string;
}
