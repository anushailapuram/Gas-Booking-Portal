import { GasRefill } from './gasrefill';

describe('GasRefill', () => {
  it('should create an instance', () => {
    expect(new GasRefill()).toBeTruthy();
  });
});
